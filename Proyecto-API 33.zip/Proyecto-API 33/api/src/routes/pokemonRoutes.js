const express = require('express');
const router = express.Router();
const knex = require('../db/knex');



console.log('pokemon routes ----->');

router.post('/', async (req, res) => {
  try {
    const [id] = await knex('pokemon').insert(req.body).returning('id');
    res.status(201).json({ id });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/', async (req, res) => {
  const all = await knex('pokemon').select();
  res.json(all);
});

router.get('/:id', async (req, res) => {
  const p = await knex('pokemon').where('id', req.params.id).first();
  if (!p) return res.status(404).json({ error: 'No existe' });
  res.json(p);
});

router.put('/:id', async (req, res) => {
  const updated = await knex('pokemon').where('id', req.params.id).update(req.body);
  if (!updated) return res.status(404).json({ error: 'No existe' });
  res.status(200).json({ updated });
});

router.delete('/:id', async (req, res) => {
  const deleted = await knex('pokemon').where('id', req.params.id).del();
  if (!deleted) return res.status(404).json({ error: 'No existe' });
  res.status(204).send();
});

module.exports = router;
