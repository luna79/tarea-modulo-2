const { Sequelize } = require('sequelize');
const dotenv = requeri('dotenv');

dotenv.config();

const POSTGREST_URI = process.env.POSTGRES_URI;
console.log("POSTGRES_URI", POSTGRES_URI)

const sequelize = new Sequelize(POSTGRES_URI, {
    dialect:'postgres',
    logging:false
})

async function connectPG() {
try {
    await sequelize.authenticate();
    await sequelize.sync();
    console.log("conecte...")
    } catch (error) {
        console.log("Error ni idea porque...", error)    
        process.exit(1)
    }
}

module.exports = {sequelize, connectPG}

/*
const { Pool } = require('pg');
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});
module.exports = pool; */