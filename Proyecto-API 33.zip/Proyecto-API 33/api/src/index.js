require('dotenv').config();

console.log('DB_HOST:', process.env.DB_HOST);
console.log('DB_USER:', process.env.DB_USER);
console.log('DB_PASSWORD (type):', typeof process.env.DB_PASSWORD, process.env.DB_PASSWORD);
console.log('DB_NAME:', process.env.DB_NAME);

const express = require('express');
const cors = require('cors');
const knex = require('knex')(require('../knexfile').development);

const app = express();
app.use(express.json());
app.use(cors());

(async () => {
  try {
    await knex.raw('SELECT 1');
    console.log('✅ Conectado a Postgres');

    // 🐞 Rutas CRUD para /pokemon
    app.get('/pokemon', async (_, res) => {
      const all = await knex('pokemon').select();
      res.json(all);
    });


    app.get('/pokemon/:id', async (req, res) => {
      const p = await knex('pokemon').where({ id: req.params.id }).first();
      console.log('Get id--------');
      p ? res.json(p) : res.status(404).json({ error: 'No encontrado' });
    });

    app.post('/pokemon', async (req, res) => {
      const [id] = await knex('pokemon').insert(req.body).returning('id');
      console.log('post id--------');
      res.status(201).json({ id });
    });

    app.put('/pokemon/:id', async (req, res) => {
      const count = await knex('pokemon')
        .where({ id: req.params.id })
        .update(req.body);
        console.log('Put id--------');
      count ? res.json({ updated: count }) : res.status(404).json({ error: 'No encontrado' });
    });

    app.delete('/pokemon/:id', async (req, res) => {
      const count = await knex('pokemon')
        .where({ id: req.params.id })
        .del();
        console.log('delete id--------');
      count ? res.json({ deleted: count }) : res.status(404).json({ error: 'No encontrado' });
    });

    const PORT = process.env.PORT || 4000;
    app.listen(PORT, () => console.log(`API escuchando en puerto ---> ${PORT}`));
   
    // Esta ruta * debe ser la última
    app.get(/.*/, (req, res) => {
      res.status(404).send('Página no encontrada.');
    });

  } catch (err) {
    console.error('❌ Error conectando a Base de Datos', err);
    process.exit(1);
  }
})();
