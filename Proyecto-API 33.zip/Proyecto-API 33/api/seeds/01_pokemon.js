// seeds/01_pokemon_seed.js
const axios = require('axios');

exports.seed = async function(knex) {
  await knex('pokemon').del();
  
  const listRes = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=150&offset=0');
  const pokemons = listRes.data.results;

  const detailed = await Promise.all(pokemons.map(p =>
    axios.get(p.url).then(r => {
      const d = r.data;
      return {
        name: d.name,
        height: d.height,
        weight: d.weight
//      types: d.types.map(t => t.type.name).join(', ')
      };
    })
  ));

  await knex.batchInsert('pokemon', detailed, 50);
  console.log(`✅ Seed: insertados ${detailed.length} Pokémon`);
};


/*const axios = require('axios');

exports.seed = async function(knex) {
  await knex('pokemon').del(); // limpia datos
 
  //await knex.raw('TRUNCATE TABLE pokemon RESTART IDENTITY CASCADE'); //Esto limpia los datos y reinicia la secuencia para que empiece desde 1 

  const allPokemon = [
    { name: 'bulbasaur', height: 7, weight: 69 },
    { name: 'ivysaur',   height: 10, weight: 130 },
    // … hasta 150 registros o los que necesites
  ];

  await knex('pokemon').insert(allPokemon); // genera ids automáticamente
 // Inserta en lotes de 100 para mejor rendimiento
 await knex.batchInsert('pokemon', allPokemon, 100);

  console.log(`✅ Seed: insertados ${allPokemon.length} Pokémon`);
};

*/