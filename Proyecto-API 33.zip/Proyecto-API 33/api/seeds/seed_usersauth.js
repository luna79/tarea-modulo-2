const bcrypt = require('bcryptjs');

exports.seed = async function(knex) {
  // Primero, limpiar la tabla para evitar duplicados
  await knex('usersauth').del();

  // Hashea la contraseña (reemplaza 'TuPassword' por la que quieras)
  const passwordHash = await bcrypt.hash(process.env.DEFAULT_PASSWORD || 'TuPassword123', 10);

  // Inserta el usuario inicial
  await knex('usersauth').insert([
    {
      username: process.env.DEFAULT_USERNAME || 'admin',
      password_hash: passwordHash
    }
  ]);
};