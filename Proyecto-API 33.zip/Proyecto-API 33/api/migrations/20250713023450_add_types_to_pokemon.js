exports.up = function(knex) {
  return knex.schema.alterTable('pokemon', table => {
    table.string('types');
  });
};

exports.down = function(knex) {
  return knex.schema.alterTable('pokemon', table => {
    table.dropColumn('types');
  });
};
