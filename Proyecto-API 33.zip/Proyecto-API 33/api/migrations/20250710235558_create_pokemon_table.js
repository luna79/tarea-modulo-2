/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
  
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
  
};

// migrations/create_pokemon_table.js
exports.up = function(knex) {
  return knex.schema.createTable('pokemon', table => {
    table.increments('id').primary();
    table.string('name').notNullable().unique();
    table.integer('height');
    table.integer('weight');
  });
};

exports.down = function(knex) {
  return knex.schema.dropTable('pokemon');
};

/*
// para crear tabla pokemon
exports.up = knex =>
  knex.schema.createTable('pokemon', t => {
    t.increments('id').primary();
    t.string('name').notNullable();
    t.integer('height');
    t.integer('weight');
  });

exports.down = knex =>
  knex.schema.dropTableIfExists('pokemon');
*/
